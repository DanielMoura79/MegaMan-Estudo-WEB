
var left_key = false;
var right_key = false;
var up_key	= false;
var down_key = false;
var x_key	= false;
var z_key = false;
var t1_key = false;
var t2_key = false;
var t3_key = false;
var t4_key = false;

window.addEventListener('load', function() {
    document.body.addEventListener("keydown", DownKey);
    document.body.addEventListener("keyup", UpKey);
});

function DownKey(e){
    if(e.keyCode == 37)
        left_key = true;

    if(e.keyCode == 38)
		up_key = true;

    if(e.keyCode == 39)
        right_key = true;

    if(e.keyCode == 40)
        down_key = true;
	
	if(e.keyCode == 49)
        t1_key = true;
	
	if(e.keyCode == 50)
        t2_key = true;
	
	if(e.keyCode == 51)
        t3_key = true;
	
	if(e.keyCode == 52)
        t4_key = true;
	
	if(e.keyCode == 88)
        x_key = true;
	
	if(e.keyCode == 90)
        z_key = true;
}

function UpKey(e){
    if(e.keyCode == 37)
        left_key = false;

    if(e.keyCode == 38)
		up_key = false;

    if(e.keyCode == 39)
        right_key = false;

    if(e.keyCode == 40)
        down_key = false;	

	if(e.keyCode == 49)
        t1_key = false;
	
	if(e.keyCode == 50)
        t2_key = false;
	
	if(e.keyCode == 51)
        t3_key = false;
	
	if(e.keyCode == 52)
        t4_key = false;
	
	if(e.keyCode == 88)
        x_key = false;	
	
	if(e.keyCode == 90)
        z_key = false;	
}

